package com.example.bicicletas;

import javafx.application.Application;

public class AppLauncher {
    public static void main(String[] args) {
        Application.launch(TallerBicicletasApp.class, args);
    }
}
